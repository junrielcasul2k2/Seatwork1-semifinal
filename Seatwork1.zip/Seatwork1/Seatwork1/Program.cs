﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//SEATWORK1 
//JUNRIEL U. CASUL     4/21/24

namespace Seatwork1
{
    internal class Program
    {
        static string[] names = new string[5];
        static void Main(string[] args)

        {


            displayNames();
            DuplicateNames();
            Consonant();
            SortAscReverse();
            SortDscReverse();
        }

        public static void displayNames()
        {


            Console.Write("");

            for (int i = 0; i < names.Length; i++)
            {

                names[i] = Console.ReadLine();

            }

            Console.WriteLine();
            Console.WriteLine("Expected Output: ");
            for (int u = 0; u < names.Length; u++)
            {
                Console.WriteLine(names[u]);
            }


        }

        //METHOD FOR SEARCHING FOR DUPLICATING NAMES
        public static void DuplicateNames()
        {
            int count = 0;

            for (int i = 0; i < names.Length; i++)
            {
                for (int u = 0; u < names.Length; u++)
                {
                    string name1 = names[u];
                    string name2 = names[i];

                    if (name1.Equals(name2))
                    {
                        count += 1;

                    }
                }

                Console.WriteLine();
                Console.WriteLine("There are " + count + " Duplicate Names");
                break;
            }


        }

        public static void Consonant()
        {
            char[] consonant = { 'b', 'c', 'd', 'f','g','h','j','k','l','m',
                                'n','o','p','q','r','s','t','v','w','x','y','z',};
            
            string[] reverse = new string[names.Length];
 
            //consonant searching
            for (int i = 0; i < names.Length; i++)
            {
                int count = 0;
                string con = names[i].ToLower();

                for (int u = 0; u < con.Length; u++)
                {

                    for (int j = 0; j < consonant.Length; j++)
                    {

                        if (con[u].Equals(consonant[j]))
                        {
                            count++;

                        }


                    }


                }
                Console.WriteLine();
                Console.WriteLine("There are " + count + " Consonant Characters in " + names[i]);      
                break;
            
            }

            //reverse
            for (int i = 0; i < names.Length; i++)
            {
                string name = names[i];
                string reverse1 = "";

                for (int rev = name.Length - 1; rev >= 0; rev--)
                {
                    reverse1 += name[rev];
                }
                
                reverse[i] = reverse1;

                Console.WriteLine(reverse[i]);
                break;     
            }
            //            Console.WriteLine("There are "+ count + " Consonant Characters in " + names);
        }

        //ASCENDING REVERSE METHOD WITH AUTOMATIC DELETE THE DUPLICATE
        public static void SortAscReverse() 
        {
            string[] reverse = new string[names.Length];

            for (int i = 0; i < names.Length; i++)
            {
                string name = names[i];
                string reverse1 = " ";

                for (int rev = name.Length - 1; rev >= 0; rev--)
                {
                    reverse1 += name[rev];
                }

                reverse[i] = reverse1;

                
            }
            for (int i = 0; i < reverse.Length - 1; i++)
            {
                for (int j = 0; j < reverse.Length - i - 1; j++)
                {
                    if (reverse[j].CompareTo(reverse[j + 1]) > 0)
                    {
                        string temp = reverse[j];
                        reverse[j] = reverse[j + 1];
                        reverse[j + 1] = temp;
 
                    }
                     
                }
                
               
            }
            //delete the duplicate reverse name
            string[] ReversedNames = reverse.Distinct(StringComparer.OrdinalIgnoreCase).ToArray();

            Console.WriteLine();

            Console.WriteLine("ASCENDING:");
            foreach (string display in ReversedNames)
            {
    
                Console.WriteLine(display);
            }
             

        }

        //DESCENDING REVERSE METHOD WITH AUTOMATIC DELTE THE DUPLICATE
        public static void SortDscReverse()
        {
            string[] reverse = new string[names.Length];

            for (int i = 0; i < names.Length; i++)
            {
                string name = names[i];
                string reverse1 = " ";

                for (int rev = name.Length - 1; rev >= 0; rev--)
                {
                    reverse1 += name[rev];
                }

                reverse[i] = reverse1;


            }
            for (int i = 0; i < reverse.Length - 1; i++)
            {
                for (int j = 0; j < reverse.Length - i - 1; j++)
                {
                    if (reverse[j].CompareTo(reverse[j + 1]) < 0)
                    {
                        string temp = reverse[j];
                        reverse[j] = reverse[j + 1];
                        reverse[j + 1] = temp;

                    }

                }


            }
            //delete the duplicate reverse name
            string[] ReversedNames = reverse.Distinct(StringComparer.OrdinalIgnoreCase).ToArray();

            Console.WriteLine();

            Console.WriteLine("DESCENDING:");
            foreach (string display in ReversedNames)
            {

                Console.WriteLine(display);
            }


        }

    }
}
